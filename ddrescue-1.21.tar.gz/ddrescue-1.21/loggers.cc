/*  GNU ddrescue - Data recovery tool
    Copyright (C) 2013-2016 Antonio Diaz Diaz.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _FILE_OFFSET_BITS 64

#include <cstdio>
#include <string>
#include <vector>
#include <sys/stat.h>

#include "block.h"
#include "loggers.h"


namespace {

const char * format_time_dhms( const long t )
  {
  static char buf[32];
  const int s = t % 60;
  const int m = ( t / 60 ) % 60;
  const int h = ( t / 3600 ) % 24;
  const long d = t / 86400;

  if( d ) snprintf( buf, sizeof buf, "%ldd:%02dh:%02dm:%02ds", d, h, m, s );
  else if( h ) snprintf( buf, sizeof buf, "%dh:%02dm:%02ds", h, m, s );
  else if( m ) snprintf( buf, sizeof buf, "%dm:%02ds", m, s );
  else snprintf( buf, sizeof buf, "%ds", s );
  return buf;
  }

} // end namespace


Rate_logger rate_logger;
Read_logger read_logger;


bool Logger::set_filename( const char * const name )
  {
  if( name && name[0] )
    {
    struct stat st;
    if( stat( name, &st ) == 0 && !S_ISREG( st.st_mode ) ) return false;
    filename_ = name;
    }
  return true;
  }


bool Logger::close_file()
  {
  if( f && !error && !write_final_timestamp( f ) ) error = true;
  if( f && std::fclose( f ) != 0 ) error = true;
  f = 0;
  return !error;
  }


bool Rate_logger::open_file()
  {
  if( !filename_ ) return true;
  if( !f )
    {
    last_time = -1;
    f = std::fopen( filename_, "w" );
    error = !f || !write_file_header( f, "Rates Logfile" ) ||
            std::fputs( "#Time  Ipos  Current_rate  Average_rate  Errors  Errsize\n", f ) == EOF;
    }
  return !error;
  }


bool Rate_logger::print_line( const long time, const long long ipos,
                              const long long a_rate, const long long c_rate,
                              const long errors, const long long errsize )
  {
  if( f && !error && time > last_time )
    {
    last_time = time;
    if( std::fprintf( f, "%2ld  0x%08llX  %8lld  %8lld  %7ld  %8lld\n",
                      time, ipos, c_rate, a_rate, errors, errsize ) < 0 )
      error = true;
    }
  return !error;
  }


bool Read_logger::open_file()
  {
  if( !filename_ ) return true;
  if( !f )
    {
    prev_is_msg = true;
    f = std::fopen( filename_, "w" );
    error = !f || !write_file_header( f, "Reads Logfile" ) ||
            std::fputs( "#  Ipos       Size  Copied_size  Error_size\n", f ) == EOF;
    }
  return !error;
  }


bool Read_logger::print_line( const long long ipos, const long long size,
                              const int copied_size, const int error_size )
  {
  if( f && !error &&
      std::fprintf( f, "0x%08llX	%lld	%d	%d\n",
                    ipos, size, copied_size, error_size ) < 0 )
    error = true;
  prev_is_msg = false;
  return !error;
  }


bool Read_logger::print_msg( const long time, const char * const msg )
  {
  if( f && !error &&
      std::fprintf( f, "%s# %s  %s\n", prev_is_msg ? "" : "\n\n",
                    format_time_dhms( time ), msg ) < 0 )
    error = true;
  prev_is_msg = true;
  return !error;
  }


bool Read_logger::print_time( const long time )
  {
  if( f && !error && time > 0 &&
      std::fprintf( f, "# %s\n", format_time_dhms( time ) ) < 0 )
    error = true;
  return !error;
  }
