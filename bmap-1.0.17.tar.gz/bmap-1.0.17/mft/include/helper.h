
extern int mft_display_man(FILE *f,const char *date,int section,struct mft_info *info,...);
extern int mft_display_sgml(FILE *f,struct mft_info *info,...);
extern int mft_display_help(FILE *f,struct mft_info *info,...);
extern int mft_display_version(FILE *f,struct mft_info *info);
