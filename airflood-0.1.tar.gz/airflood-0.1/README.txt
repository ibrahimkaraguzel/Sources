Para compilar:

$ make

Despues logeate como root e instalalo con el siguiente comando:

# make install

Visita www.rusoblanco.com ;)
