#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char *argv[])
{
    int i, j, k;

    if (k == 1)
    {         
        while (i < 10)
        {
            printf("1\n");
        }

        printf("2\n");
    }

    if (k == 2)
    {
        do
        {
            printf("3\n");
        } while (j < 15);
    }

    return 0;
}

