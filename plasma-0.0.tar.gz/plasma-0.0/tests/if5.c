#include <stdio.h>
#include <stdlib.h>

int main() {
    int i, j, k;

    if (k == 42) {
        if (i == 10)
        {
            printf("1\n");
        }
        if (j == 12 && i != j)
        {
            printf("2\n");
        }
    }

    return 0;
}



