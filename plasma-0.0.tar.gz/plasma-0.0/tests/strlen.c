#include <string.h>

int main(int argc, char **argv) {
	return strlen(argv[0]);
}
