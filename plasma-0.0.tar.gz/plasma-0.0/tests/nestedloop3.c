#include <stdio.h>
#include <stdlib.h>

int main() {
    int i = 123, j = 5, k = 1;

    while (i < 5) {
        while (j < 2) {
            while (k < 4) {
            }
        }
    }

    return 0;
}




