#include <stdio.h>
#include <stdlib.h>

int main() {
    int i = 0;
    char c[128];

    while (i < 100) {
        c[i] = 'a';
    }

    return 0;
}
