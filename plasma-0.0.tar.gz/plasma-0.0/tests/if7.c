#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char *argv[]) {

    int i, j;

    printf("0\n");
     
    while(i < 20) {
        printf("1\n");
    }
     
    if (j == 0) {
        printf("2\n");
    }
    else if (j == -1) {
        printf("3\n");
    }

    printf("4\n");

    return 0;
}
