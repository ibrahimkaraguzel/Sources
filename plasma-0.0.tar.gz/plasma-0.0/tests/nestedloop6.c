#include <stdio.h>
#include <stdlib.h>

int main() {
    int i = 123, j = 5, k;

    if (i == 1) {
        while (i <= 2) {
            while (j <= 3) {
                while (k <= 4) {
                    if (i == 5) {
                        while (i <= 6) {
                            while (j <= 7) {
                                while (k <= 8) {
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return 0;
}







