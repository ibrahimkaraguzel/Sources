#include <stdio.h>
#include <stdlib.h>

int main() {
    int i = 123, j = 5;

    if (i != 0 || i > time(NULL) || i != j || i > 5 || j < 10) {
        printf("1\n");
    }
    else {
        printf("2\n");
    }

    printf("3\n");

    return 0;
}



