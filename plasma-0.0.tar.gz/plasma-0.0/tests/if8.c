#include <stdio.h>
#include <stdlib.h>

int main() {
    int i;

    for (i = 0 ; i < 10 ; i++) {
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
        if (i == 0) { printf("1\n"); } else { printf("2\n"); }
    }

    return 0;
}

