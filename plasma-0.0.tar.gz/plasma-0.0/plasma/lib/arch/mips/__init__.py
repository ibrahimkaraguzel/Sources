import plasma.lib.arch.mips.output
import plasma.lib.arch.mips.utils
import plasma.lib.arch.mips.process_ast

registered = [
    # TODO
    # process_ast.fuse_inst_with_if,

    process_ast.search_li,
]
